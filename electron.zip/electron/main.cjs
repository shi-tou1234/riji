const { app, BrowserWindow, nativeImage } = require('electron');
const path = require('path');

const ICON_DATA_URL = "data:image/svg+xml,%3Csvg%20xmlns%3D%27http%3A//www.w3.org/2000/svg%27%20width%3D%27256%27%20height%3D%27256%27%20viewBox%3D%270%200%20256%20256%27%3E%3Crect%20x%3D%2724%27%20y%3D%2724%27%20width%3D%27208%27%20height%3D%27208%27%20rx%3D%2764%27%20fill%3D%27%23111111%27/%3E%3Cg%20fill%3D%27none%27%20stroke%3D%27%23ffffff%27%20stroke-width%3D%2716%27%20stroke-linecap%3D%27round%27%20stroke-linejoin%3D%27round%27%3E%3Cpath%20d%3D%27M96%2080h64%27/%3E%3Cpath%20d%3D%27M96%20128h48%27/%3E%3Cpath%20d%3D%27M96%20176h32%27/%3E%3Cpath%20d%3D%27M80%2068a16%2016%200%200%201%2016-16h80a16%2016%200%200%201%2016%2016v120a16%2016%200%200%201-16%2016H96a16%2016%200%200%201-16-16z%27%20opacity%3D%270.9%27/%3E%3Cpath%20d%3D%27M180%2084l8%208%27/%3E%3Cpath%20d%3D%27M190%2074l8%208%27/%3E%3C/g%3E%3C/svg%3E";

function createWindow() {
  const win = new BrowserWindow({
    width: 1200,
    height: 800,
    icon: nativeImage.createFromDataURL(ICON_DATA_URL),
    webPreferences: {
      nodeIntegration: true,
      contextIsolation: false,
    },
    autoHideMenuBar: true,
    title: "我的日记本"
  });

  win.on('page-title-updated', (e) => {
    e.preventDefault();
  });

  const isDev = !app.isPackaged;

  if (isDev) {
    win.loadURL('http://localhost:5173');
    // win.webContents.openDevTools();
  } else {
    win.loadFile(path.join(__dirname, '../dist/index.html'));
  }
}

app.whenReady().then(() => {
  createWindow();

  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) {
      createWindow();
    }
  });
});

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') {
    app.quit();
  }
});
