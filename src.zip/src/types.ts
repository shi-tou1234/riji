export interface DiaryEntry {
  id: string;
  userId?: string;
  date: string; // YYYY-MM-DD
  content: string; // HTML or JSON
  createdAt: number;
  updatedAt: number;
}

export type DiaryExport = {
  version: number;
  data: DiaryEntry[];
};

export interface UserProfile {
  id: string;
  username: string;
  signature: string;
  avatarDataUrl: string | null;
  createdAt: number;
  updatedAt: number;
}

export interface UserRecord extends UserProfile {
  passwordSalt: string;
  passwordHash: string;
}
