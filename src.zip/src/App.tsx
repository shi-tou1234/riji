import { useEffect, useMemo, useState, useCallback, useRef } from 'react'
import Sidebar from './components/Sidebar'
import Editor from './components/Editor'
import Auth from './components/Auth'
import { DiaryEntry, DiaryExport, UserProfile } from './types'
import {
  deleteAccount,
  deleteDiary,
  getAllDiariesForUser,
  getDiaryByDateForUser,
  importDiaries,
  saveDiary,
  setCurrentUserId,
  updateUserProfile,
} from './db'
import { v4 as uuidv4 } from 'uuid'
import { format, parseISO } from 'date-fns'
import { zhCN } from 'date-fns/locale'
import { AnimatePresence, motion } from 'framer-motion'
import { cn } from './lib/utils'
import { FileUp, ImagePlus, Lock, Sparkles, Trash2 } from 'lucide-react'

function App() {
  const [user, setUser] = useState<UserProfile | null>(null)
  const [entries, setEntries] = useState<DiaryEntry[]>([])
  const [currentEntryId, setCurrentEntryId] = useState<string | null>(null)
  const [draftContent, setDraftContent] = useState('')
  const saveTimeoutRef = useRef<number | null>(null)
  const draftRef = useRef<{ entryId: string | null; content: string }>({ entryId: null, content: '' })
  const [toast, setToast] = useState<{ id: string; message: string; kind: 'success' | 'error' } | null>(null)
  const [isIntroOpen, setIsIntroOpen] = useState(false)

  const introKey = useMemo(() => (user ? `riji.introSeen.v1.${user.id}` : null), [user])

  useEffect(() => {
    if (!toast) return
    const t = window.setTimeout(() => setToast(null), 2600)
    return () => window.clearTimeout(t)
  }, [toast])

  const loadEntries = useCallback(async (userId: string) => {
    try {
      const data = await getAllDiariesForUser(userId)
      setEntries(data)
    } catch (error) {
      console.error('Failed to load diaries', error)
    }
  }, [])

  const entryMap = useMemo(() => {
    const map = new Map<string, DiaryEntry>()
    for (const entry of entries) map.set(entry.id, entry)
    return map
  }, [entries])

  const flushPendingSave = useCallback(async () => {
    if (!user) return
    if (!saveTimeoutRef.current) return
    window.clearTimeout(saveTimeoutRef.current)
    saveTimeoutRef.current = null

    const entryId = draftRef.current.entryId
    if (!entryId) return
    const base = entryMap.get(entryId)
    if (!base) return

    const updatedEntry: DiaryEntry = {
      ...base,
      content: draftRef.current.content,
      updatedAt: Date.now(),
      userId: user.id,
    }
    await saveDiary(updatedEntry)
    setEntries((prev) => prev.map((e) => (e.id === updatedEntry.id ? updatedEntry : e)))
  }, [entryMap, user])

  useEffect(() => {
    const onVisibilityChange = () => {
      if (document.visibilityState === 'hidden') {
        void flushPendingSave()
      }
    }
    const onBeforeUnload = () => {
      void flushPendingSave()
    }
    document.addEventListener('visibilitychange', onVisibilityChange)
    window.addEventListener('beforeunload', onBeforeUnload)
    return () => {
      document.removeEventListener('visibilitychange', onVisibilityChange)
      window.removeEventListener('beforeunload', onBeforeUnload)
    }
  }, [flushPendingSave])

  const handleSelect = useCallback(
    async (id: string) => {
      await flushPendingSave()
      setCurrentEntryId(id)
    },
    [flushPendingSave]
  )

  useEffect(() => {
    if (!currentEntryId) {
      setDraftContent('')
      draftRef.current = { entryId: null, content: '' }
      return
    }
    const entry = entryMap.get(currentEntryId)
    const content = entry?.content ?? ''
    setDraftContent(content)
    draftRef.current = { entryId: currentEntryId, content }
  }, [currentEntryId, entryMap])

  const handleNew = async () => {
    if (!user) return
    await flushPendingSave()
    const today = format(new Date(), 'yyyy-MM-dd')
    const existing = await getDiaryByDateForUser(user.id, today)
    if (existing) return setCurrentEntryId(existing.id)

    const newEntry: DiaryEntry = {
      id: uuidv4(),
      userId: user.id,
      date: today,
      content: '',
      createdAt: Date.now(),
      updatedAt: Date.now(),
    }

    await saveDiary(newEntry)
    setEntries(prev => [...prev, newEntry])
    setCurrentEntryId(newEntry.id)
  }

  const handleUpdate = (content: string) => {
    if (!user) return
    if (!currentEntryId) return
    const entry = entryMap.get(currentEntryId)
    if (!entry) return

    draftRef.current = { entryId: currentEntryId, content }

    if (saveTimeoutRef.current) {
      window.clearTimeout(saveTimeoutRef.current)
    }

    saveTimeoutRef.current = window.setTimeout(async () => {
      saveTimeoutRef.current = null
      const base = entryMap.get(currentEntryId)
      if (!base) return
      const updatedEntry: DiaryEntry = {
        ...base,
        content,
        updatedAt: Date.now(),
        userId: user.id,
      }
      await saveDiary(updatedEntry)
      setEntries((prev) => prev.map((e) => (e.id === updatedEntry.id ? updatedEntry : e)))
    }, 700)
  }

  const handleDelete = async (id: string) => {
    await flushPendingSave()
    await deleteDiary(id)
    setEntries(prev => prev.filter(e => e.id !== id))
    if (currentEntryId === id) {
      setCurrentEntryId(null)
    }
  }

  const handleExport = async () => {
    await flushPendingSave()
    const exportData: DiaryExport = {
      version: 1,
      data: entries
    }
    const mostRecentDate = entries.reduce((acc, e) => (e.date && e.date > acc ? e.date : acc), '')
    const exportDate = currentEntry?.date ?? (mostRecentDate || format(new Date(), 'yyyy-MM-dd'))
    const blob = new Blob([JSON.stringify(exportData, null, 2)], { type: 'application/json' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = `riji-export-${exportDate}.json`
    document.body.appendChild(a)
    a.click()
    document.body.removeChild(a)
    URL.revokeObjectURL(url)
  }

  const handleImport = async (file: File) => {
    if (!user) return
    const reader = new FileReader()
    reader.onload = async (e) => {
      try {
        const content = e.target?.result as string
        const importData: DiaryExport = JSON.parse(content)
        if (Array.isArray(importData.data)) {
          const normalized = importData.data
            .filter((x) => x && typeof x === 'object')
            .map((x) => {
              const entry = x as DiaryEntry
              return {
                ...entry,
                id: entry.id || uuidv4(),
                userId: user.id,
                createdAt: typeof entry.createdAt === 'number' ? entry.createdAt : Date.now(),
                updatedAt: typeof entry.updatedAt === 'number' ? entry.updatedAt : Date.now(),
                content: typeof entry.content === 'string' ? entry.content : '',
              } satisfies DiaryEntry
            })
          await importDiaries(normalized)
          await loadEntries(user.id)
          setToast({ id: uuidv4(), message: '导入成功', kind: 'success' })
        }
      } catch (error) {
        console.error('Import failed', error)
        setToast({ id: uuidv4(), message: '导入失败：文件格式无效', kind: 'error' })
      }
    }
    reader.readAsText(file)
  }

  const currentEntry = currentEntryId ? entryMap.get(currentEntryId) : undefined

  const handleAuthed = async (authedUser: UserProfile) => {
    setUser(authedUser)
    await loadEntries(authedUser.id)
    setToast({ id: uuidv4(), message: `欢迎回来，${authedUser.username}`, kind: 'success' })
    const key = `riji.introSeen.v1.${authedUser.id}`
    if (!localStorage.getItem(key)) setIsIntroOpen(true)
  }

  const handleLogout = async () => {
    await flushPendingSave()
    setCurrentUserId(null)
    setUser(null)
    setEntries([])
    setCurrentEntryId(null)
    setDraftContent('')
    draftRef.current = { entryId: null, content: '' }
    setIsIntroOpen(false)
  }

  const handleProfileSave = async (patch: Partial<Pick<UserProfile, 'username' | 'signature' | 'avatarDataUrl'>>) => {
    if (!user) return
    const updated = await updateUserProfile(user.id, patch)
    setUser(updated)
    setToast({ id: uuidv4(), message: '资料已更新', kind: 'success' })
  }

  const handleDeleteAccount = async () => {
    if (!user) return
    await flushPendingSave()
    await deleteAccount(user.id)
    if (introKey) localStorage.removeItem(introKey)
    await handleLogout()
    setToast({ id: uuidv4(), message: '账号已注销', kind: 'success' })
  }

  if (!user) {
    return <Auth onAuthed={handleAuthed} />
  }

  return (
    <div className="flex h-screen text-foreground overflow-hidden font-sans antialiased">
      <Sidebar
        user={user}
        entries={entries}
        currentEntryId={currentEntryId}
        onSelect={handleSelect}
        onNew={handleNew}
        onDelete={handleDelete}
        onImport={handleImport}
        onExport={handleExport}
        onProfileSave={handleProfileSave}
        onLogout={handleLogout}
        onDeleteAccount={handleDeleteAccount}
      />
      <main className="flex-1 flex flex-col h-full overflow-hidden relative">
        <AnimatePresence>
          {toast && (
            <motion.div
              key={toast.id}
              className="absolute right-4 top-4 z-40"
              initial={{ opacity: 0, y: -8, scale: 0.98 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: -8, scale: 0.98 }}
              transition={{ type: 'spring', stiffness: 320, damping: 26 }}
            >
              <div
                className={cn(
                  "rounded-2xl border bg-background/80 backdrop-blur px-4 py-3 shadow-lg text-sm",
                  toast.kind === 'error' ? 'border-destructive/30' : 'border-border/70'
                )}
              >
                <div className="font-medium">{toast.kind === 'error' ? '操作失败' : '完成'}</div>
                <div className="mt-1 text-muted-foreground">{toast.message}</div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
        <AnimatePresence mode="wait">
          {currentEntry ? (
            <motion.div
              key={currentEntry.id}
              className="flex-1 overflow-y-auto p-6 sm:p-10"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: 10 }}
              transition={{ type: 'spring', stiffness: 260, damping: 26 }}
            >
              <div className="max-w-5xl mx-auto">
                <div className="mb-6 flex items-start justify-between gap-4">
                  <div>
                    <h1 className="text-3xl sm:text-4xl font-bold tracking-tight">
                      {format(parseISO(currentEntry.date), 'yyyy年MM月dd日', { locale: zhCN })}
                    </h1>
                    <p className="mt-2 text-sm sm:text-base text-muted-foreground">
                      {format(parseISO(currentEntry.date), 'EEEE', { locale: zhCN })} · 每一天都值得记录
                    </p>
                  </div>
                  <div className="hidden sm:flex items-center gap-2">
                    <span className="inline-flex items-center rounded-full border bg-background/70 px-3 py-1 text-xs text-muted-foreground shadow-sm">
                      自动保存
                    </span>
                    <span className="inline-flex items-center rounded-full border bg-background/70 px-3 py-1 text-xs text-muted-foreground shadow-sm">
                      支持图片
                    </span>
                  </div>
                </div>
                <motion.div
                  className="rounded-2xl border bg-background/75 shadow-sm backdrop-blur p-5 sm:p-7"
                  initial={{ opacity: 0, scale: 0.99 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ type: 'spring', stiffness: 260, damping: 28, delay: 0.03 }}
                >
                  <Editor
                    key={currentEntry.id}
                    content={draftContent}
                    onChange={handleUpdate}
                  />
                </motion.div>
              </div>
            </motion.div>
          ) : (
            <motion.div
              key="empty"
              className="flex-1 flex flex-col items-center justify-center p-8"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: 10 }}
              transition={{ type: 'spring', stiffness: 260, damping: 26 }}
            >
              <div className="w-full max-w-lg text-center">
                <div className="mx-auto mb-5 h-14 w-14 rounded-2xl bg-primary shadow-sm overflow-hidden grid place-items-center text-primary-foreground text-lg font-semibold">
                  {user.avatarDataUrl ? (
                    <img src={user.avatarDataUrl} alt="avatar" className="h-full w-full object-cover" />
                  ) : (
                    user.username.slice(0, 1).toUpperCase()
                  )}
                </div>
                <h2 className="text-2xl sm:text-3xl font-bold tracking-tight">
                  欢迎{entries.length === 0 ? '开始' : '回来'}，{user.username}
                </h2>
                <p className="mt-3 text-muted-foreground">
                  {user.signature ? user.signature : '从左侧选择一篇日记，或现在就开始记录今天。'}
                </p>
                <div className="mt-6 flex justify-center">
                  <button
                    onClick={handleNew}
                    className="rounded-xl bg-primary text-primary-foreground px-5 py-2.5 shadow-sm hover:shadow transition-all hover:opacity-95"
                  >
                    开始写作
                  </button>
                </div>
                <div className="mt-4 text-xs text-muted-foreground">
                  提示：支持插入图片、粘贴内容、自动保存
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </main>

      <AnimatePresence>
        {isIntroOpen && (
          <motion.div
            className="fixed inset-0 z-50 flex items-center justify-center p-4"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
          >
            <motion.button
              className="absolute inset-0 bg-black/40"
              onClick={() => {
                if (introKey) localStorage.setItem(introKey, '1')
                setIsIntroOpen(false)
              }}
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
            />
            <motion.div
              role="dialog"
              aria-modal="true"
              className="relative w-full max-w-lg rounded-3xl border bg-background text-foreground shadow-2xl overflow-hidden"
              initial={{ opacity: 0, y: 14, scale: 0.98 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: 14, scale: 0.98 }}
              transition={{ type: 'spring', stiffness: 320, damping: 26 }}
            >
              <div className="p-6 border-b flex items-center gap-3">
                <div className="h-11 w-11 rounded-2xl bg-primary text-primary-foreground shadow-sm grid place-items-center">
                  <Sparkles className="h-5 w-5" />
                </div>
                <div className="leading-tight">
                  <div className="text-sm text-muted-foreground">新用户指南</div>
                  <div className="text-xl font-semibold tracking-tight">3 分钟上手我的日记本</div>
                </div>
              </div>

              <div className="p-6 grid gap-3">
                <div className="rounded-2xl border bg-background/70 px-4 py-3 flex items-start gap-3">
                  <div className="h-9 w-9 rounded-xl bg-secondary/70 grid place-items-center">
                    <Lock className="h-4 w-4" />
                  </div>
                  <div className="min-w-0">
                    <div className="text-sm font-semibold">隐私优先</div>
                    <div className="text-sm text-muted-foreground">数据只保存在本机，且每次打开都需要登录。</div>
                  </div>
                </div>
                <div className="rounded-2xl border bg-background/70 px-4 py-3 flex items-start gap-3">
                  <div className="h-9 w-9 rounded-xl bg-secondary/70 grid place-items-center">
                    <ImagePlus className="h-4 w-4" />
                  </div>
                  <div className="min-w-0">
                    <div className="text-sm font-semibold">多图写作</div>
                    <div className="text-sm text-muted-foreground">支持一次插入多张图片；点选图片后可一键删除。</div>
                  </div>
                </div>
                <div className="rounded-2xl border bg-background/70 px-4 py-3 flex items-start gap-3">
                  <div className="h-9 w-9 rounded-xl bg-secondary/70 grid place-items-center">
                    <FileUp className="h-4 w-4" />
                  </div>
                  <div className="min-w-0">
                    <div className="text-sm font-semibold">导入导出</div>
                    <div className="text-sm text-muted-foreground">可导出备份文件，导出名默认使用当前日记日期。</div>
                  </div>
                </div>
                <div className="rounded-2xl border bg-background/70 px-4 py-3 flex items-start gap-3">
                  <div className="h-9 w-9 rounded-xl bg-secondary/70 grid place-items-center">
                    <Trash2 className="h-4 w-4" />
                  </div>
                  <div className="min-w-0">
                    <div className="text-sm font-semibold">资料与注销</div>
                    <div className="text-sm text-muted-foreground">可修改头像/用户名/签名，也支持注销账号并清空数据。</div>
                  </div>
                </div>
              </div>

              <div className="p-6 pt-0 flex items-center justify-end gap-2">
                <button
                  onClick={() => {
                    if (introKey) localStorage.setItem(introKey, '1')
                    setIsIntroOpen(false)
                  }}
                  className="rounded-2xl bg-primary text-primary-foreground px-5 py-2.5 text-sm hover:opacity-90 transition-opacity"
                >
                  我知道了
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  )
}

export default App
