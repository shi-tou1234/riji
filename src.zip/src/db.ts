import { openDB, DBSchema, IDBPDatabase } from 'idb';
import { DiaryEntry, UserProfile, UserRecord } from './types';

interface DiaryDB extends DBSchema {
  diaries: {
    key: string;
    value: DiaryEntry;
    indexes: { 'by-date': string; 'by-user': string; 'by-user-date': [string, string] };
  };
  users: {
    key: string;
    value: UserRecord;
    indexes: { 'by-username': string };
  };
}

const DB_NAME = 'riji-db';
const DIARIES_STORE = 'diaries';
const USERS_STORE = 'users';
const SESSION_KEY = 'riji.currentUserId';

let dbPromise: Promise<IDBPDatabase<DiaryDB>>;

export const initDB = () => {
  if (!dbPromise) {
    dbPromise = openDB<DiaryDB>(DB_NAME, 3, {
      upgrade(db, _oldVersion, _newVersion, transaction) {
        const diariesStore = db.objectStoreNames.contains(DIARIES_STORE)
          ? transaction.objectStore(DIARIES_STORE)
          : db.createObjectStore(DIARIES_STORE, { keyPath: 'id' });

        if (!diariesStore.indexNames.contains('by-date')) {
          diariesStore.createIndex('by-date', 'date');
        }
        if (!diariesStore.indexNames.contains('by-user')) {
          diariesStore.createIndex('by-user', 'userId');
        }
        if (!diariesStore.indexNames.contains('by-user-date')) {
          diariesStore.createIndex('by-user-date', ['userId', 'date']);
        }

        if (!db.objectStoreNames.contains(USERS_STORE)) {
          const store = db.createObjectStore(USERS_STORE, {
            keyPath: 'id',
          });
          store.createIndex('by-username', 'username', { unique: true });
        } else {
          const store = transaction.objectStore(USERS_STORE);
          if (!store.indexNames.contains('by-username')) {
            store.createIndex('by-username', 'username', { unique: true });
          }
        }
      },
    });
  }
  return dbPromise;
};

export const saveDiary = async (entry: DiaryEntry) => {
  const db = await initDB();
  return db.put(DIARIES_STORE, entry);
};

export const getDiary = async (id: string) => {
  const db = await initDB();
  return db.get(DIARIES_STORE, id);
};

export const getDiaryByDate = async (date: string) => {
  const db = await initDB();
  return db.getFromIndex(DIARIES_STORE, 'by-date', date);
};

export const getAllDiaries = async () => {
  const db = await initDB();
  return db.getAll(DIARIES_STORE);
};

export const getAllDiariesForUser = async (userId: string) => {
  const db = await initDB();
  return db.getAllFromIndex(DIARIES_STORE, 'by-user', userId);
};

export const getDiaryByDateForUser = async (userId: string, date: string) => {
  const db = await initDB();
  return db.getFromIndex(DIARIES_STORE, 'by-user-date', [userId, date]);
};

export const deleteDiary = async (id: string) => {
  const db = await initDB();
  return db.delete(DIARIES_STORE, id);
};

export const importDiaries = async (entries: DiaryEntry[]) => {
  const db = await initDB();
  const tx = db.transaction(DIARIES_STORE, 'readwrite');
  await Promise.all(entries.map(entry => tx.store.put(entry)));
  await tx.done;
};

const textEncoder = new TextEncoder();

const toBase64 = (data: ArrayBuffer) => {
  const bytes = new Uint8Array(data);
  let binary = '';
  for (let i = 0; i < bytes.byteLength; i += 1) {
    binary += String.fromCharCode(bytes[i]);
  }
  return btoa(binary);
};

const fromBase64 = (b64: string) => {
  const binary = atob(b64);
  const bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i += 1) {
    bytes[i] = binary.charCodeAt(i);
  }
  return bytes.buffer;
};

const constantTimeEqual = (a: Uint8Array, b: Uint8Array) => {
  if (a.length !== b.length) return false;
  let diff = 0;
  for (let i = 0; i < a.length; i += 1) {
    diff |= a[i] ^ b[i];
  }
  return diff === 0;
};

const derivePasswordHash = async (password: string, saltB64: string) => {
  const salt = fromBase64(saltB64);
  const keyMaterial = await crypto.subtle.importKey(
    'raw',
    textEncoder.encode(password),
    { name: 'PBKDF2' },
    false,
    ['deriveBits']
  );
  const bits = await crypto.subtle.deriveBits(
    {
      name: 'PBKDF2',
      salt,
      iterations: 120_000,
      hash: 'SHA-256',
    },
    keyMaterial,
    256
  );
  return toBase64(bits);
};

const generateSalt = () => {
  const salt = new Uint8Array(16);
  crypto.getRandomValues(salt);
  return toBase64(salt.buffer);
};

export const setCurrentUserId = (userId: string | null) => {
  if (!userId) {
    localStorage.removeItem(SESSION_KEY);
    return;
  }
  localStorage.setItem(SESSION_KEY, userId);
};

export const getCurrentUserId = () => localStorage.getItem(SESSION_KEY);

export const getUserById = async (id: string) => {
  const db = await initDB();
  return db.get(USERS_STORE, id);
};

export const getUserByUsername = async (username: string) => {
  const db = await initDB();
  const normalized = username.trim();
  if (!normalized) return undefined;
  return db.getFromIndex(USERS_STORE, 'by-username', normalized);
};

export const registerUser = async (params: { id: string; username: string; password: string }) => {
  const username = params.username.trim();
  if (!username) throw new Error('用户名不能为空');
  if (params.password.length < 6) throw new Error('密码至少 6 位');

  const db = await initDB();
  const existing = await db.getFromIndex(USERS_STORE, 'by-username', username);
  if (existing) throw new Error('该用户名已被注册');

  const salt = generateSalt();
  const hash = await derivePasswordHash(params.password, salt);
  const now = Date.now();

  const user: UserRecord = {
    id: params.id,
    username,
    signature: '',
    avatarDataUrl: null,
    passwordSalt: salt,
    passwordHash: hash,
    createdAt: now,
    updatedAt: now,
  };

  await db.put(USERS_STORE, user);
  return user as UserRecord;
};

export const loginUser = async (params: { username: string; password: string }) => {
  const username = params.username.trim();
  const db = await initDB();
  const user = await db.getFromIndex(USERS_STORE, 'by-username', username);
  if (!user) throw new Error('用户名或密码错误');

  const hash = await derivePasswordHash(params.password, user.passwordSalt);
  const ok = constantTimeEqual(
    new Uint8Array(fromBase64(hash)),
    new Uint8Array(fromBase64(user.passwordHash))
  );
  if (!ok) throw new Error('用户名或密码错误');
  return user as UserRecord;
};

export const updateUserProfile = async (
  userId: string,
  patch: Partial<Pick<UserProfile, 'username' | 'signature' | 'avatarDataUrl'>>
) => {
  const db = await initDB();
  const user = await db.get(USERS_STORE, userId);
  if (!user) throw new Error('用户不存在');

  const nextUsername = (patch.username ?? user.username).trim();
  if (!nextUsername) throw new Error('用户名不能为空');

  if (nextUsername !== user.username) {
    const existing = await db.getFromIndex(USERS_STORE, 'by-username', nextUsername);
    if (existing && existing.id !== userId) throw new Error('该用户名已被占用');
  }

  const updated: UserRecord = {
    ...user,
    username: nextUsername,
    signature: typeof patch.signature === 'string' ? patch.signature : user.signature,
    avatarDataUrl: patch.avatarDataUrl !== undefined ? patch.avatarDataUrl : user.avatarDataUrl,
    updatedAt: Date.now(),
  };

  await db.put(USERS_STORE, updated);
  return updated as UserRecord;
};

export const claimLegacyDiaries = async (userId: string) => {
  const db = await initDB();
  const tx = db.transaction(DIARIES_STORE, 'readwrite');
  let cursor = await tx.store.openCursor();
  while (cursor) {
    const value = cursor.value as DiaryEntry;
    if (!value.userId) {
      await cursor.update({ ...value, userId });
    }
    cursor = await cursor.continue();
  }
  await tx.done;
};

export const deleteAccount = async (userId: string) => {
  const db = await initDB();
  const tx = db.transaction([DIARIES_STORE, USERS_STORE], 'readwrite');

  const diariesStore = tx.objectStore(DIARIES_STORE);
  const userIndex = diariesStore.index('by-user');
  let cursor = await userIndex.openCursor(userId);
  while (cursor) {
    await cursor.delete();
    cursor = await cursor.continue();
  }

  await tx.objectStore(USERS_STORE).delete(userId);
  await tx.done;
};
