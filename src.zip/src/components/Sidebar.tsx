import { DiaryEntry, UserProfile } from '../types';
import { format, parseISO } from 'date-fns';
import { zhCN } from 'date-fns/locale';
import { Plus, Trash2, Download, Upload, Search, PenLine, Settings2, LogOut, Camera, X } from 'lucide-react';
import { cn } from '../lib/utils';
import { useEffect, useMemo, useState } from 'react';
import { AnimatePresence, motion } from 'framer-motion';

interface SidebarProps {
  user: UserProfile;
  entries: DiaryEntry[];
  currentEntryId: string | null;
  onSelect: (id: string) => void;
  onNew: () => void;
  onDelete: (id: string) => void;
  onImport: (file: File) => void;
  onExport: () => Promise<void> | void;
  onProfileSave: (
    patch: Partial<Pick<UserProfile, 'username' | 'signature' | 'avatarDataUrl'>>
  ) => Promise<void> | void;
  onLogout: () => void;
  onDeleteAccount: () => Promise<void> | void;
}

export default function Sidebar({
  user,
  entries,
  currentEntryId,
  onSelect,
  onNew,
  onDelete,
  onImport,
  onExport,
  onProfileSave,
  onLogout,
  onDeleteAccount,
}: SidebarProps) {
  const [searchTerm, setSearchTerm] = useState('');
  const [deleteTarget, setDeleteTarget] = useState<DiaryEntry | null>(null);
  const [isProfileOpen, setIsProfileOpen] = useState(false);
  const [isDeleteAccountOpen, setIsDeleteAccountOpen] = useState(false);
  const [isDeletingAccount, setIsDeletingAccount] = useState(false);
  const [profileUsername, setProfileUsername] = useState(user.username);
  const [profileSignature, setProfileSignature] = useState(user.signature);
  const [profileAvatar, setProfileAvatar] = useState<string | null>(user.avatarDataUrl);
  const [profileError, setProfileError] = useState<string | null>(null);
  const [isSavingProfile, setIsSavingProfile] = useState(false);

  const getPlainText = (html: string) => html.replace(/<[^>]*>/g, '').replace(/\s+/g, ' ').trim()

  const filteredEntries = useMemo(() => {
    const q = searchTerm.trim().toLowerCase()
    return entries
      .filter((entry) => {
        if (!q) return true
        return getPlainText(entry.content).toLowerCase().includes(q) || entry.date.includes(q)
      })
      .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
  }, [entries, searchTerm])

  useEffect(() => {
    if (!deleteTarget) return
    const onKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') setDeleteTarget(null)
    }
    window.addEventListener('keydown', onKeyDown)
    return () => window.removeEventListener('keydown', onKeyDown)
  }, [deleteTarget])

  useEffect(() => {
    if (!isProfileOpen) return
    const onKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') setIsProfileOpen(false)
    }
    window.addEventListener('keydown', onKeyDown)
    return () => window.removeEventListener('keydown', onKeyDown)
  }, [isProfileOpen])

  useEffect(() => {
    if (!isDeleteAccountOpen) return
    const onKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') setIsDeleteAccountOpen(false)
    }
    window.addEventListener('keydown', onKeyDown)
    return () => window.removeEventListener('keydown', onKeyDown)
  }, [isDeleteAccountOpen])

  useEffect(() => {
    if (!isProfileOpen) return
    setProfileUsername(user.username)
    setProfileSignature(user.signature)
    setProfileAvatar(user.avatarDataUrl)
    setProfileError(null)
  }, [isProfileOpen, user.avatarDataUrl, user.signature, user.username])

  const handleImportClick = () => {
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = 'application/json';
    input.onchange = (e) => {
      const file = (e.target as HTMLInputElement).files?.[0];
      if (file) {
        onImport(file);
      }
    };
    input.click();
  };

  const readAvatarDataUrl = async (file: File) => {
    if (file.size > 6 * 1024 * 1024) throw new Error('图片太大了，请选择更小的图片')
    if (!file.type.startsWith('image/')) throw new Error('请选择图片文件')
    try {
      const bitmap = await createImageBitmap(file)
      const max = 256
      const scale = Math.min(1, max / Math.max(bitmap.width, bitmap.height))
      const w = Math.max(1, Math.round(bitmap.width * scale))
      const h = Math.max(1, Math.round(bitmap.height * scale))
      const canvas = document.createElement('canvas')
      canvas.width = w
      canvas.height = h
      const ctx = canvas.getContext('2d')
      if (!ctx) throw new Error('无法处理图片')
      ctx.drawImage(bitmap, 0, 0, w, h)
      bitmap.close?.()
      return canvas.toDataURL('image/jpeg', 0.88)
    } catch {
      const dataUrl = await new Promise<string>((resolve, reject) => {
        const reader = new FileReader()
        reader.onerror = () => reject(new Error('读取图片失败'))
        reader.onload = () => resolve(String(reader.result))
        reader.readAsDataURL(file)
      })
      return dataUrl
    }
  }

  return (
    <div className="w-[340px] border-r bg-background/70 backdrop-blur flex flex-col h-screen">
      <div className="p-5 border-b space-y-4">
        <div className="flex items-center gap-3">
          <div className="h-10 w-10 rounded-xl bg-primary text-primary-foreground shadow-sm flex items-center justify-center">
            <PenLine className="h-5 w-5" />
          </div>
          <div className="leading-tight">
            <div className="font-bold text-lg">我的日记本</div>
            <div className="text-xs text-muted-foreground">把每一天写成故事</div>
          </div>
        </div>

        <div className="rounded-2xl border bg-background/70 shadow-sm p-3 flex items-center gap-3">
          <button
            onClick={() => setIsProfileOpen(true)}
            className="flex-1 flex items-center gap-3 text-left min-w-0"
          >
            <div className="h-10 w-10 rounded-xl bg-secondary/70 overflow-hidden grid place-items-center text-sm font-semibold">
              {user.avatarDataUrl ? (
                <img src={user.avatarDataUrl} alt="avatar" className="h-full w-full object-cover" />
              ) : (
                user.username.slice(0, 1).toUpperCase()
              )}
            </div>
            <div className="min-w-0">
              <div className="text-sm font-semibold truncate">{user.username}</div>
              <div className="text-xs text-muted-foreground truncate">
                {user.signature ? user.signature : '点击编辑资料'}
              </div>
            </div>
          </button>
          <button
            onClick={() => setIsProfileOpen(true)}
            className="h-10 w-10 rounded-xl border bg-background/70 hover:bg-secondary/70 transition-colors grid place-items-center"
            title="编辑资料"
          >
            <Settings2 className="h-4 w-4" />
          </button>
          <button
            onClick={onLogout}
            className="h-10 w-10 rounded-xl border bg-background/70 hover:bg-secondary/70 transition-colors grid place-items-center"
            title="退出登录"
          >
            <LogOut className="h-4 w-4" />
          </button>
        </div>

        <button
          onClick={onNew}
          className="w-full flex items-center justify-center gap-2 rounded-xl bg-primary text-primary-foreground px-3 py-2.5 shadow-sm hover:shadow transition-all hover:opacity-95"
        >
          <Plus size={18} /> 新建日记
        </button>
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <input
            type="text"
            placeholder="搜索日记..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-10 pr-3 py-2.5 rounded-xl border bg-background/80 text-sm shadow-sm focus:outline-none focus:ring-2 focus:ring-ring/20"
          />
        </div>
      </div>

      <div className="flex-1 overflow-y-auto p-3 space-y-2">
        {filteredEntries.length === 0 ? (
          <div className="text-center text-muted-foreground p-6 text-sm">
            没有找到日记。
          </div>
        ) : (
          filteredEntries.map((entry) => (
            <motion.div
              key={entry.id}
              onClick={() => onSelect(entry.id)}
              layout
              className={cn(
                "group flex items-start justify-between gap-3 p-3 rounded-xl cursor-pointer border bg-background/75 hover:bg-background shadow-sm transition-all hover:shadow-md",
                currentEntryId === entry.id
                  ? "ring-2 ring-primary/10 border-primary/20"
                  : "border-border/60"
              )}
              initial={{ opacity: 0, y: 6 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: 6 }}
            >
              <div className="flex flex-col overflow-hidden">
                <span className="font-semibold">
                  {format(parseISO(entry.date), 'yyyy年MM月dd日', { locale: zhCN })}
                </span>
                <span className="text-xs text-muted-foreground">
                  {format(parseISO(entry.date), 'EEEE', { locale: zhCN })} · {format(parseISO(entry.date), 'yyyy-MM-dd')}
                </span>
                <span className="mt-2 text-xs text-muted-foreground/90 truncate">
                  {getPlainText(entry.content) || '（暂无内容）'}
                </span>
              </div>
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  setDeleteTarget(entry)
                }}
                className="opacity-0 group-hover:opacity-100 p-2 hover:bg-destructive hover:text-destructive-foreground rounded-lg transition-all"
              >
                <Trash2 size={14} />
              </button>
            </motion.div>
          ))
        )}
      </div>

      <div className="p-4 border-t flex gap-2 bg-background/70 backdrop-blur">
        <button
          onClick={handleImportClick}
          className="flex-1 flex items-center justify-center gap-2 text-sm border px-3 py-2.5 rounded-xl bg-background/70 hover:bg-secondary/70 transition-colors"
        >
          <Upload size={14} /> 导入
        </button>
        <button
          onClick={onExport}
          className="flex-1 flex items-center justify-center gap-2 text-sm border px-3 py-2.5 rounded-xl bg-background/70 hover:bg-secondary/70 transition-colors"
        >
          <Download size={14} /> 导出
        </button>
      </div>

      <AnimatePresence>
        {deleteTarget && (
          <motion.div
            className="fixed inset-0 z-50 flex items-center justify-center p-4"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
          >
            <motion.button
              className="absolute inset-0 bg-black/40"
              onClick={() => setDeleteTarget(null)}
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
            />
            <motion.div
              role="dialog"
              aria-modal="true"
              className="relative w-full max-w-md rounded-2xl border bg-background text-foreground shadow-2xl"
              initial={{ opacity: 0, y: 10, scale: 0.98 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: 10, scale: 0.98 }}
              transition={{ type: 'spring', stiffness: 320, damping: 26 }}
            >
              <div className="p-5 border-b">
                <div className="text-sm text-muted-foreground">我的日记本</div>
                <div className="mt-1 text-lg font-semibold tracking-tight">删除这篇日记？</div>
              </div>
              <div className="p-5 text-sm text-muted-foreground">
                删除后无法恢复。你确定要删除 <span className="font-medium text-foreground">{format(parseISO(deleteTarget.date), 'yyyy年MM月dd日', { locale: zhCN })}</span> 的日记吗？
              </div>
              <div className="p-5 pt-0 flex gap-2 justify-end">
                <button
                  onClick={() => setDeleteTarget(null)}
                  className="rounded-xl border bg-background px-4 py-2 text-sm hover:bg-secondary/60 transition-colors"
                >
                  取消
                </button>
                <button
                  onClick={() => {
                    const id = deleteTarget.id
                    setDeleteTarget(null)
                    onDelete(id)
                  }}
                  className="rounded-xl bg-destructive text-destructive-foreground px-4 py-2 text-sm hover:opacity-90 transition-opacity"
                >
                  确认删除
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      <AnimatePresence>
        {isProfileOpen && (
          <motion.div
            className="fixed inset-0 z-50 flex items-center justify-center p-4"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
          >
            <motion.button
              className="absolute inset-0 bg-black/40"
              onClick={() => setIsProfileOpen(false)}
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
            />
            <motion.div
              role="dialog"
              aria-modal="true"
              className="relative w-full max-w-md rounded-2xl border bg-background text-foreground shadow-2xl overflow-hidden"
              initial={{ opacity: 0, y: 10, scale: 0.98 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: 10, scale: 0.98 }}
              transition={{ type: 'spring', stiffness: 320, damping: 26 }}
            >
              <div className="p-5 border-b flex items-center justify-between gap-3">
                <div>
                  <div className="text-sm text-muted-foreground">我的日记本</div>
                  <div className="mt-1 text-lg font-semibold tracking-tight">个人资料</div>
                </div>
                <button
                  onClick={() => setIsProfileOpen(false)}
                  className="h-10 w-10 rounded-xl border bg-background/70 hover:bg-secondary/70 transition-colors grid place-items-center"
                  title="关闭"
                >
                  <X className="h-4 w-4" />
                </button>
              </div>

              <div className="p-5 space-y-4">
                <div className="flex items-center gap-4">
                  <div className="h-16 w-16 rounded-2xl bg-secondary/70 overflow-hidden grid place-items-center text-lg font-semibold">
                    {profileAvatar ? (
                      <img src={profileAvatar} alt="avatar" className="h-full w-full object-cover" />
                    ) : (
                      profileUsername.slice(0, 1).toUpperCase()
                    )}
                  </div>
                  <div className="flex-1">
                    <label className="inline-flex items-center gap-2 rounded-xl border bg-background/70 px-3 py-2 text-sm hover:bg-secondary/70 transition-colors cursor-pointer">
                      <Camera className="h-4 w-4" /> 上传头像
                      <input
                        type="file"
                        className="hidden"
                        accept="image/*"
                        onChange={async (e) => {
                          const file = e.target.files?.[0]
                          e.target.value = ''
                          if (!file) return
                          setProfileError(null)
                          try {
                            const dataUrl = await readAvatarDataUrl(file)
                            setProfileAvatar(dataUrl)
                          } catch (err) {
                            const message = err instanceof Error ? err.message : '上传失败'
                            setProfileError(message)
                          }
                        }}
                      />
                    </label>
                    <div className="mt-2 flex gap-2">
                      <button
                        type="button"
                        className="text-xs text-muted-foreground underline underline-offset-4 hover:opacity-80"
                        onClick={() => setProfileAvatar(null)}
                      >
                        移除头像
                      </button>
                    </div>
                  </div>
                </div>

                <div className="space-y-2">
                  <div className="text-xs text-muted-foreground">用户名</div>
                  <input
                    value={profileUsername}
                    onChange={(e) => setProfileUsername(e.target.value)}
                    className="w-full rounded-2xl border bg-background/80 px-4 py-3 text-sm shadow-sm focus:outline-none focus:ring-2 focus:ring-ring/20"
                    placeholder="请输入用户名"
                    autoComplete="username"
                  />
                </div>

                <div className="space-y-2">
                  <div className="text-xs text-muted-foreground">个性签名</div>
                  <textarea
                    value={profileSignature}
                    onChange={(e) => setProfileSignature(e.target.value)}
                    className="w-full min-h-24 resize-none rounded-2xl border bg-background/80 px-4 py-3 text-sm shadow-sm focus:outline-none focus:ring-2 focus:ring-ring/20"
                    placeholder="写一句你喜欢的话…"
                  />
                </div>

                <AnimatePresence>
                  {profileError && (
                    <motion.div
                      className="rounded-2xl border border-border/70 bg-background/70 px-4 py-3 text-sm text-muted-foreground"
                      initial={{ opacity: 0, y: -6 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, y: -6 }}
                    >
                      {profileError}
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>

              <div className="p-5 pt-0 flex items-center justify-between gap-3">
                <div className="flex items-center gap-2">
                  <button
                    onClick={onLogout}
                    className="rounded-xl border bg-background px-4 py-2 text-sm hover:bg-secondary/60 transition-colors"
                  >
                    退出登录
                  </button>
                  <button
                    onClick={() => setIsDeleteAccountOpen(true)}
                    className="rounded-xl border border-destructive/40 bg-background px-4 py-2 text-sm text-destructive hover:bg-destructive/10 transition-colors"
                  >
                    注销账号
                  </button>
                </div>
                <div className="flex gap-2">
                  <button
                    onClick={() => setIsProfileOpen(false)}
                    className="rounded-xl border bg-background px-4 py-2 text-sm hover:bg-secondary/60 transition-colors"
                  >
                    取消
                  </button>
                  <button
                    disabled={isSavingProfile}
                    onClick={async () => {
                      setProfileError(null)
                      const username = profileUsername.trim()
                      if (!username) {
                        setProfileError('请输入用户名')
                        return
                      }
                      setIsSavingProfile(true)
                      try {
                        await onProfileSave({
                          username,
                          signature: profileSignature,
                          avatarDataUrl: profileAvatar,
                        })
                        setIsProfileOpen(false)
                      } catch (err) {
                        const message = err instanceof Error ? err.message : '保存失败'
                        setProfileError(message)
                      } finally {
                        setIsSavingProfile(false)
                      }
                    }}
                    className="rounded-xl bg-primary text-primary-foreground px-4 py-2 text-sm hover:opacity-90 transition-opacity disabled:opacity-60"
                  >
                    {isSavingProfile ? '保存中…' : '保存'}
                  </button>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      <AnimatePresence>
        {isDeleteAccountOpen && (
          <motion.div
            className="fixed inset-0 z-50 flex items-center justify-center p-4"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
          >
            <motion.button
              className="absolute inset-0 bg-black/40"
              onClick={() => setIsDeleteAccountOpen(false)}
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
            />
            <motion.div
              role="dialog"
              aria-modal="true"
              className="relative w-full max-w-md rounded-2xl border bg-background text-foreground shadow-2xl overflow-hidden"
              initial={{ opacity: 0, y: 10, scale: 0.98 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: 10, scale: 0.98 }}
              transition={{ type: 'spring', stiffness: 320, damping: 26 }}
            >
              <div className="p-5 border-b">
                <div className="text-sm text-muted-foreground">我的日记本</div>
                <div className="mt-1 text-lg font-semibold tracking-tight">注销账号？</div>
              </div>
              <div className="p-5 text-sm text-muted-foreground space-y-2">
                <div>将永久删除该账号及其所有日记内容，且无法恢复。</div>
                <div className="text-destructive">请确认你真的要注销。</div>
              </div>
              <div className="p-5 pt-0 flex gap-2 justify-end">
                <button
                  onClick={() => setIsDeleteAccountOpen(false)}
                  className="rounded-xl border bg-background px-4 py-2 text-sm hover:bg-secondary/60 transition-colors"
                >
                  取消
                </button>
                <button
                  disabled={isDeletingAccount}
                  onClick={async () => {
                    setIsDeletingAccount(true)
                    try {
                      await onDeleteAccount()
                      setIsDeleteAccountOpen(false)
                      setIsProfileOpen(false)
                    } finally {
                      setIsDeletingAccount(false)
                    }
                  }}
                  className="rounded-xl bg-destructive text-destructive-foreground px-4 py-2 text-sm hover:opacity-90 transition-opacity disabled:opacity-60"
                >
                  {isDeletingAccount ? '处理中…' : '确认注销'}
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
