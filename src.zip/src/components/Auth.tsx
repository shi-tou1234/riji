import { useMemo, useState } from 'react'
import { AnimatePresence, motion } from 'framer-motion'
import { LogIn, UserPlus } from 'lucide-react'
import { v4 as uuidv4 } from 'uuid'
import { claimLegacyDiaries, loginUser, registerUser } from '../db'
import type { UserProfile } from '../types'

type Props = {
  onAuthed: (user: UserProfile) => void
}

export default function Auth({ onAuthed }: Props) {
  const [mode, setMode] = useState<'login' | 'register'>('login')
  const [username, setUsername] = useState('')
  const [password, setPassword] = useState('')
  const [confirm, setConfirm] = useState('')
  const [error, setError] = useState<string | null>(null)
  const [isSubmitting, setIsSubmitting] = useState(false)

  const title = useMemo(() => (mode === 'login' ? '登录' : '注册'), [mode])

  const submit = async () => {
    setError(null)
    const u = username.trim()
    if (!u) {
      setError('请输入用户名')
      return
    }
    if (password.length < 6) {
      setError('密码至少 6 位')
      return
    }
    if (mode === 'register' && password !== confirm) {
      setError('两次输入的密码不一致')
      return
    }

    setIsSubmitting(true)
    try {
      const user =
        mode === 'login'
          ? await loginUser({ username: u, password })
          : await registerUser({ id: uuidv4(), username: u, password })

      if (mode === 'register') {
        await claimLegacyDiaries(user.id)
      }
      onAuthed(user)
    } catch (e) {
      const message = e instanceof Error ? e.message : '操作失败'
      setError(message)
    } finally {
      setIsSubmitting(false)
    }
  }

  return (
    <div className="min-h-screen flex items-center justify-center px-4 py-10">
      <motion.div
        className="w-full max-w-md rounded-3xl border bg-background/80 backdrop-blur shadow-xl"
        initial={{ opacity: 0, y: 12, scale: 0.98 }}
        animate={{ opacity: 1, y: 0, scale: 1 }}
        transition={{ type: 'spring', stiffness: 300, damping: 26 }}
      >
        <div className="p-7 border-b">
          <div className="flex items-center gap-3">
            <div className="h-11 w-11 rounded-2xl bg-primary text-primary-foreground shadow-sm grid place-items-center">
              {mode === 'login' ? <LogIn size={18} /> : <UserPlus size={18} />}
            </div>
            <div className="leading-tight">
              <div className="text-sm text-muted-foreground">我的日记本</div>
              <div className="text-xl font-semibold tracking-tight">{title}</div>
            </div>
          </div>
        </div>

        <div className="p-7 space-y-4">
          <div className="space-y-2">
            <div className="text-xs text-muted-foreground">用户名</div>
            <input
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              className="w-full rounded-2xl border bg-background/80 px-4 py-3 text-sm shadow-sm focus:outline-none focus:ring-2 focus:ring-ring/20"
              placeholder="请输入用户名"
              autoComplete="username"
            />
          </div>
          <div className="space-y-2">
            <div className="text-xs text-muted-foreground">密码</div>
            <input
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full rounded-2xl border bg-background/80 px-4 py-3 text-sm shadow-sm focus:outline-none focus:ring-2 focus:ring-ring/20"
              placeholder="请输入密码（至少 6 位）"
              type="password"
              autoComplete={mode === 'login' ? 'current-password' : 'new-password'}
              onKeyDown={(e) => {
                if (e.key === 'Enter') submit()
              }}
            />
          </div>

          <AnimatePresence>
            {mode === 'register' && (
              <motion.div
                className="space-y-2"
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: 'auto' }}
                exit={{ opacity: 0, height: 0 }}
              >
                <div className="text-xs text-muted-foreground">确认密码</div>
                <input
                  value={confirm}
                  onChange={(e) => setConfirm(e.target.value)}
                  className="w-full rounded-2xl border bg-background/80 px-4 py-3 text-sm shadow-sm focus:outline-none focus:ring-2 focus:ring-ring/20"
                  placeholder="再次输入密码"
                  type="password"
                  autoComplete="new-password"
                  onKeyDown={(e) => {
                    if (e.key === 'Enter') submit()
                  }}
                />
              </motion.div>
            )}
          </AnimatePresence>

          <AnimatePresence>
            {error && (
              <motion.div
                className="rounded-2xl border border-border/70 bg-background/70 px-4 py-3 text-sm text-muted-foreground"
                initial={{ opacity: 0, y: -6 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -6 }}
              >
                {error}
              </motion.div>
            )}
          </AnimatePresence>

          <button
            disabled={isSubmitting}
            onClick={submit}
            className="w-full rounded-2xl bg-primary text-primary-foreground px-4 py-3 text-sm shadow-sm hover:shadow transition-all disabled:opacity-60"
          >
            {isSubmitting ? '处理中…' : title}
          </button>

          <div className="pt-2 flex items-center justify-center gap-2 text-sm text-muted-foreground">
            {mode === 'login' ? '还没有账号？' : '已经有账号？'}
            <button
              className="text-foreground underline underline-offset-4 hover:opacity-80"
              onClick={() => {
                setError(null)
                setMode(mode === 'login' ? 'register' : 'login')
              }}
            >
              {mode === 'login' ? '去注册' : '去登录'}
            </button>
          </div>
        </div>
      </motion.div>
    </div>
  )
}
