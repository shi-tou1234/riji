import { useEditor, EditorContent } from '@tiptap/react'
import StarterKit from '@tiptap/starter-kit'
import Image from '@tiptap/extension-image'
import Placeholder from '@tiptap/extension-placeholder'
import { Bold, Italic, Strikethrough, List, ListOrdered, Image as ImageIcon, Quote, Undo, Redo, Trash2 } from 'lucide-react'
import { cn } from '../lib/utils'
import type { Editor as TiptapEditor } from '@tiptap/core'

interface EditorProps {
  content: string;
  onChange: (content: string) => void;
  editable?: boolean;
}

const MenuBar = ({ editor }: { editor: TiptapEditor | null }) => {
  if (!editor) {
    return null
  }

  const iconButtonClass = (active?: boolean) =>
    cn(
      'inline-flex h-9 w-9 items-center justify-center rounded-lg transition-colors',
      active ? 'bg-primary/10 text-primary' : 'text-muted-foreground hover:bg-secondary/70 hover:text-foreground',
    )

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files ?? [])
    e.target.value = ''
    if (files.length === 0) return

    const toDataUrl = (file: File) =>
      new Promise<string>((resolve, reject) => {
        const reader = new FileReader()
        reader.onerror = () => reject(new Error('读取图片失败'))
        reader.onload = () => resolve(String(reader.result))
        reader.readAsDataURL(file)
      })

    const images = files.filter((f) => f.type.startsWith('image/'))
    if (images.length === 0) return

    const dataUrls = await Promise.all(images.map((f) => toDataUrl(f)))

    for (const src of dataUrls) {
      editor.chain().focus().setImage({ src }).run()
      editor.chain().focus().createParagraphNear().run()
    }
  }

  return (
    <div className="flex flex-wrap items-center gap-1.5 p-2 mb-4 border rounded-xl bg-background/70 sticky top-0 z-20 backdrop-blur shadow-sm">
      <button
        title="加粗"
        onClick={() => editor.chain().focus().toggleBold().run()}
        disabled={!editor.can().chain().focus().toggleBold().run()}
        className={iconButtonClass(editor.isActive('bold'))}
      >
        <Bold size={18} />
      </button>
      <button
        title="斜体"
        onClick={() => editor.chain().focus().toggleItalic().run()}
        disabled={!editor.can().chain().focus().toggleItalic().run()}
        className={iconButtonClass(editor.isActive('italic'))}
      >
        <Italic size={18} />
      </button>
      <button
        title="删除线"
        onClick={() => editor.chain().focus().toggleStrike().run()}
        disabled={!editor.can().chain().focus().toggleStrike().run()}
        className={iconButtonClass(editor.isActive('strike'))}
      >
        <Strikethrough size={18} />
      </button>
      <div className="w-px h-6 bg-border mx-1" />
      <button
        title="无序列表"
        onClick={() => editor.chain().focus().toggleBulletList().run()}
        className={iconButtonClass(editor.isActive('bulletList'))}
      >
        <List size={18} />
      </button>
      <button
        title="有序列表"
        onClick={() => editor.chain().focus().toggleOrderedList().run()}
        className={iconButtonClass(editor.isActive('orderedList'))}
      >
        <ListOrdered size={18} />
      </button>
      <div className="w-px h-6 bg-border mx-1" />
      <button
        title="引用"
        onClick={() => editor.chain().focus().toggleBlockquote().run()}
        className={iconButtonClass(editor.isActive('blockquote'))}
      >
        <Quote size={18} />
      </button>
      <div className="w-px h-6 bg-border mx-1" />
      <label title="插入图片" className="inline-flex h-9 w-9 items-center justify-center rounded-lg cursor-pointer text-muted-foreground hover:bg-secondary/70 hover:text-foreground transition-colors">
        <ImageIcon size={18} />
        <input type="file" className="hidden" accept="image/*" multiple onChange={handleFileUpload} />
      </label>
      <button
        title="删除图片"
        onClick={() => editor.chain().focus().deleteSelection().run()}
        disabled={!editor.isActive('image')}
        className={cn(
          'inline-flex h-9 w-9 items-center justify-center rounded-lg transition-colors',
          editor.isActive('image')
            ? 'text-muted-foreground hover:bg-secondary/70 hover:text-foreground'
            : 'text-muted-foreground/40 cursor-not-allowed'
        )}
      >
        <Trash2 size={18} />
      </button>
      <div className="w-px h-6 bg-border mx-1 ml-auto" />
      <button
        title="撤销"
        onClick={() => editor.chain().focus().undo().run()}
        disabled={!editor.can().chain().focus().undo().run()}
        className={cn('inline-flex h-9 w-9 items-center justify-center rounded-lg text-muted-foreground hover:bg-secondary/70 hover:text-foreground transition-colors disabled:opacity-50 disabled:hover:bg-transparent disabled:hover:text-muted-foreground')}
      >
        <Undo size={18} />
      </button>
      <button
        title="重做"
        onClick={() => editor.chain().focus().redo().run()}
        disabled={!editor.can().chain().focus().redo().run()}
        className={cn('inline-flex h-9 w-9 items-center justify-center rounded-lg text-muted-foreground hover:bg-secondary/70 hover:text-foreground transition-colors disabled:opacity-50 disabled:hover:bg-transparent disabled:hover:text-muted-foreground')}
      >
        <Redo size={18} />
      </button>
    </div>
  )
}

export default function Editor({ content, onChange, editable = true }: EditorProps) {
  const editor = useEditor({
    extensions: [
      StarterKit,
      Image.configure({
        allowBase64: true,
      }),
      Placeholder.configure({
        placeholder: '今天发生了什么有趣的事...',
      }),
    ],
    content,
    editable,
    onUpdate: ({ editor }) => {
      onChange(editor.getHTML())
    },
    editorProps: {
      attributes: {
        class: 'prose prose-sm sm:prose lg:prose-lg xl:prose-2xl mx-auto focus:outline-none min-h-[500px]',
      },
    },
  })

  return (
    <div className="w-full">
      {editable && <MenuBar editor={editor} />}
      <EditorContent editor={editor} />
    </div>
  )
}
